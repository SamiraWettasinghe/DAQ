# MLX90621-Lite
A lightweight Arduino library for the MLX90621 thermopile array sensor.
