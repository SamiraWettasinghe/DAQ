var searchData=
[
  ['tak4',['tak4',['../class_m_l_x90621.html#a030d11dc9cea07fb217fa6c06a3b81b5',1,'MLX90621']]],
  ['tgc',['tgc',['../class_m_l_x90621.html#a94f3dcdfcf237c804d4bcdeebf53f843',1,'MLX90621']]]
];
