var searchData=
[
  ['initialise',['initialise',['../class_m_l_x90621.html#aa4b137b5928378ce6d00345cb9f77f56',1,'MLX90621']]]
];
