var searchData=
[
  ['twos_5f16',['twos_16',['../class_m_l_x90621.html#a2aead2fad3c606661b2430f93dbc5f52',1,'MLX90621']]],
  ['twos_5f8',['twos_8',['../class_m_l_x90621.html#a6fa28111abab3c558096e0d490af14b4',1,'MLX90621']]]
];
