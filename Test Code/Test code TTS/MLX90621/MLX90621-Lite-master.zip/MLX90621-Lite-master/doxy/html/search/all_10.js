var searchData=
[
  ['unsigned_5f16',['unsigned_16',['../class_m_l_x90621.html#a1aaac15eb91ba94f9fdbe3de37cc4112',1,'MLX90621']]]
];
