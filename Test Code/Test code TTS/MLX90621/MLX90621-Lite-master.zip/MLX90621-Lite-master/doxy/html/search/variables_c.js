var searchData=
[
  ['write_5fosc_5ftrim',['WRITE_OSC_TRIM',['../_m_l_x90621_8h.html#a498fba228d1b8b7ed5eeaa27838631d6',1,'MLX90621.h']]],
  ['write_5fregister',['WRITE_REGISTER',['../_m_l_x90621_8h.html#a9fe1d072a84bc5c67e0b72830cb78b4c',1,'MLX90621.h']]]
];
