var searchData=
[
  ['num_5fpixels',['NUM_PIXELS',['../_m_l_x90621_8h.html#ab5d6c48b52a9c1e599add5f36605ce54',1,'MLX90621.h']]]
];
