var searchData=
[
  ['load_5fsensor',['load_sensor',['../class_m_l_x90621.html#a1b6dac89e5171ea5a4f6ada62d6f4ade',1,'MLX90621']]]
];
