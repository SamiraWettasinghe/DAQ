var searchData=
[
  ['b_5fcp',['b_cp',['../class_m_l_x90621.html#a177293e63ef621c64d65007ec85eda92',1,'MLX90621']]],
  ['b_5fi_5fscale',['b_i_scale',['../class_m_l_x90621.html#ad2d4104e82e551a90c987cce68074f97',1,'MLX90621']]]
];
