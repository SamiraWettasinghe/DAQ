var searchData=
[
  ['write_5ftrimming_5fvalue',['write_trimming_value',['../class_m_l_x90621.html#af292e8d12205448a578805f93dec2677',1,'MLX90621']]]
];
