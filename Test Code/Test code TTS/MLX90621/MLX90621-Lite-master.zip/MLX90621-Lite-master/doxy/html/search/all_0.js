var searchData=
[
  ['_5frefresh_5frate',['_refresh_rate',['../class_m_l_x90621.html#a116993f422bd9dca3b0892e01691cfb2',1,'MLX90621']]]
];
