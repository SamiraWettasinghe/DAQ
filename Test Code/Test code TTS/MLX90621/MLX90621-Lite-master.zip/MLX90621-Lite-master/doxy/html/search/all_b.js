var searchData=
[
  ['osc_5fcheck',['OSC_CHECK',['../_m_l_x90621_8h.html#af99a5f3927a7ad2ce487af62f98fbf76',1,'MLX90621.h']]],
  ['osc_5ftrim_5fvalue',['OSC_TRIM_VALUE',['../_m_l_x90621_8h.html#a4c1f498d5f14885899e1b569525be4d1',1,'MLX90621.h']]]
];
