var searchData=
[
  ['set_5fconfiguration',['set_configuration',['../class_m_l_x90621.html#a908f99c29aa960159f4a84a2afb25e8f',1,'MLX90621']]]
];
